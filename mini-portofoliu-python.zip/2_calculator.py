# 2. Calculator simplu cu operatii matematice
number = int(input("Enter first number: "))

while True:
    op = input("Alege o operatie (+, -, *, /) sau orice altceva pentru a opri: ")
    if op not in "+-*/":
        break
    number2 = int(input("Enter second number: "))
    if op == "+":
        number += number2
    elif op == "-":
        number -= number2
    elif op == "*":
        number *= number2
    elif op == "/":
        number /= number2
    print("Rezultat:", number)