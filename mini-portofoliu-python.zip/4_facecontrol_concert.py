# 4. Facecontrol pentru concert rock
age = int(input("How old are you: "))
tiket = input("Ai bilet? (da/nu): ")

if age >= 18 and age <= 100:
    if tiket == "da":
        print("Acces permis, Welcome!")
    else:
        print("Lipsa bilet, ACCES INTERZIS!")
elif age < 18 and age >= 15:
    if tiket == "da":
        permis = input("Ai permisiune scrisă de la părinți? (da/nu): ")
        if permis == "da":
            print("Acces permis!")
        else:
            print("Acces interzis!")
else:
    print("Vârsta nu corespunde, acces interzis!")