# 3. Convertor de temperatură: Celsius ↔ Fahrenheit
grade = float(input("Introduce temperatura: "))
unitate = input("Unitatea temperaturii introduse (c pentru Celsius, f pentru Fahrenheit): ").lower()

if unitate == 'c':
    rezultat = (grade * 9/5) + 32
    print(f"{grade}°C echivalează cu {rezultat:.2f}°F")
elif unitate == 'f':
    rezultat = (grade - 32) * 5/9
    print(f"{grade}°F echivalează cu {rezultat:.2f}°C")
else:
    print("Unitate invalidă. Te rog alege 'c' sau 'f'.")