# 1. Calcularea rădăcinii pătrate prin două metode
import math
number  = int(input("Enter a number: "))
sqrt1 = math.sqrt(number)
sqrt2 = number ** 0.5
print("Radacina patrata prin functia math.sqrt:", sqrt1)
print("Radacina patrata prin metoda exponentiala:", sqrt2)