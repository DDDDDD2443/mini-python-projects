# 5. Verificare admitere la examen pentru permis de conducere
age = int(input("How old are you: "))

if 18 <= age <= 100:
    accesMed = input("Ai cartela medicala? (da/nu): ")
    if accesMed == "da":
        exTeorie = input("Ai susținut examenul teoretic? (da/nu): ")
        if exTeorie == "da":
            puncteAcumulate = int(input("Introdu numărul de puncte acumulate: "))
            if puncteAcumulate < 21:
                print("Ești admis!")
            else:
                print("Nu ești admis la examen.")
        else:
            print("Nu ai susținut examenul teoretic.")
    else:
        print("Nu ai cartela medicală.")
else:
    print("Vârsta nu corespunde pentru examen.")