# Python Mini Projects 🐍

This repository contains several beginner-friendly Python exercises that simulate real-world scenarios using user input and logic structures.

## Contents

1. `1_radacina_patrata.py` - Square root calculator using two different methods.
2. `2_calculator.py` - A simple calculator that performs arithmetic operations.
3. `3_convertor_temperatura.py` - Temperature converter (Celsius ↔ Fahrenheit).
4. `4_facecontrol_concert.py` - Access validation logic for a rock concert.
5. `5_admitere_permis.py` - Driving exam eligibility check based on user input.